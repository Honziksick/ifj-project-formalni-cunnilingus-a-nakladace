#!/usr/bin/env bash
# Use at Merlin: ./run.sh MyProgram.zig  (both MyProgram.zig and ifj24.zig in the current directory)
zig run $1
