// hlavicka pro interpret
int inter(tSymbolTable *ST, tListOfInstr *instrList);
